---
name: "openclaw-server-setup"
description: "OpenClaw + Codex CLI + tmux 的多 Agent 标准作业手册（完整版）"
version: "1.15.0"
lastUpdated: "2026-02-26"
---

# OpenClaw + Codex CLI + tmux 多 Agent 标准操作手册（8 Agent）

## 0. 目标约束（必须遵守）

- OpenClaw 负责：需求分析、任务路由、状态汇报、审阅调度、测试结果同步。
- **代码实现必须由 Codex CLI 在 tmux 执行**。
- 主会话/主模型：`gpt-5.3-codex-spark`，Codex 落地模型：`gpt-5.3-codex`。
- 服务器差异：普通服务器默认 `--full-auto`，`tokyo-claw` 遇到 Landlock 限制时使用 `--dangerously-bypass-approvals-and-sandbox`。
- 每次调用可追踪：`session_key`、`task_id`、变更文件清单、验证命令、结果状态。

## 1. 环境与依赖（最小可运行）

```bash
dnf install -y cmake gcc gcc-c++ make git curl
node -v || curl -fsSL https://raw.githubusercontent.com/nvm-sh/nvm/v0.39.7/install.sh | bash
npm install -g openclaw
openclaw setup
mkdir -p ~/.openclaw/workspace
mkdir -p ~/.openclaw/workspace/{coordinator,doc-writer,frontend-dev,backend-dev,reviewer,tester,deployer}
codex --help > /tmp/codex-help.txt
```

## 2. `openclaw.json` 核心模板（可直接复制）

```json
{
  "meta": {
    "lastTouchedVersion": "2026.2.26",
    "lastTouchedAt": "2026-02-26T08:00:00.000Z"
  },
  "models": {
    "providers": {
      "openai-codex": {
        "baseUrl": "https://api.openai.com/v1",
        "api": "openai-completions",
        "apiKey": "<OPENAI_API_KEY>",
        "models": [
          { "id": "gpt-5.3-codex-spark", "name": "GPT-5.3 Codex Spark" },
          { "id": "gpt-5.3-codex", "name": "GPT-5.3 Codex" }
        ]
      }
    }
  },
  "agents": {
    "defaults": {
      "model": { "primary": "openai-codex/gpt-5.3-codex-spark" },
      "workspace": "/root/.openclaw/workspace",
      "maxConcurrent": 4,
      "subagents": {
        "maxConcurrent": 8,
        "maxChildrenPerAgent": 5,
        "maxSpawnDepth": 2
      },
      "thinkingDefault": "high",
      "timeoutSeconds": 300
    },
    "list": [
      { "id": "main", "default": true, "name": "大总管", "workspace": "/root/.openclaw/workspace", "model": { "primary": "openai-codex/gpt-5.3-codex-spark" } },
      { "id": "coordinator", "name": "coordinator", "workspace": "/root/.openclaw/workspace-coordinator", "model": { "primary": "openai-codex/gpt-5.3-codex-spark" } },
      { "id": "doc-writer", "name": "doc-writer", "workspace": "/root/.openclaw/workspace-doc-writer", "model": { "primary": "openai-codex/gpt-5.3-codex-spark" } },
      { "id": "frontend-dev", "name": "frontend-dev", "workspace": "/root/.openclaw/workspace-frontend-dev", "model": { "primary": "openai-codex/gpt-5.3-codex-spark" } },
      { "id": "backend-dev", "name": "backend-dev", "workspace": "/root/.openclaw/workspace-backend-dev", "model": { "primary": "openai-codex/gpt-5.3-codex-spark" } },
      { "id": "reviewer", "name": "reviewer", "workspace": "/root/.openclaw/workspace-reviewer", "model": { "primary": "openai-codex/gpt-5.3-codex-spark" } },
      { "id": "tester", "name": "tester", "workspace": "/root/.openclaw/workspace-tester", "model": { "primary": "openai-codex/gpt-5.3-codex-spark" } },
      { "id": "deployer", "name": "deployer", "workspace": "/root/.openclaw/workspace-deployer", "model": { "primary": "openai-codex/gpt-5.3-codex-spark" } }
    ]
  },
  "tools": {
    "alsoAllow": ["lobster"],
    "codex_exec_access": "rw-all",
    "agentToAgent": {
      "enabled": true,
      "allow": ["main", "coordinator", "doc-writer", "frontend-dev", "backend-dev", "reviewer", "tester", "deployer"]
    },
    "exec": { "notifyOnExit": false }
  },
  "commands": { "native": true, "nativeSkills": false, "restart": true, "ownerDisplay": "raw" },
  "channels_telegram": {
    "enabled": true,
    "dmPolicy": "pairing",
    "allowFrom": [],
    "groupPolicy": "allowlist",
    "groupAllowFrom": ["-1003776988848"],
    "groups": {
      "-1003776988848": { "requireMention": false }
    },
    "botToken": "<TELEGRAM_BOT_TOKEN>",
    "streaming": "partial",
    "blockStreaming": true
  },
  "gateway_auth": { "token": "300bedf3c61aa436a61d67a31d8b99" }
}
```

## 3. Telegram 安全边界（生产建议）

- `groupPolicy: allowlist`
- `groupAllowFrom: ["-1003776988848"]`
- `dmPolicy: pairing`
- `allowFrom: []`
- 私聊必须 `/pair` 后才能使用（首次可配合管理员提前配对）

常用命令：

```bash
openclaw config set channels_telegram.groupPolicy allowlist
openclaw config set channels_telegram.groupAllowFrom '["-1003776988848"]'
openclaw config set channels_telegram.dmPolicy pairing
openclaw config set channels_telegram.allowFrom '[]'
openclaw config set channels_telegram.commands.native true
openclaw config set channels_telegram.commands.nativeSkills false
```

## 4. 8 Agent 角色定义（不能精简版）

### 4.1 角色总览

| Agent | 角色 | 主要职责 | 技能主线 | 输出给谁 |
|---|---|---|---|---|
| `main` | 大总管 | 需求确认、任务编排、上下游聚合、验收闭环 | `agent-manager,feature-development` | 用户 |
| `coordinator` | 任务协调 | 先拆分再分发，控制并发与优先级 | `task-decomposer,smart-workflow` | `frontend-dev/backend-dev/reviewer/tester/deployer/doc-writer` |
| `doc-writer` | 文档治理 | 需求文档/实施文档/验收说明/变更说明 | `writing-plans,docx,changelog-generator` | `main` |
| `frontend-dev` | 前端开发 | Vue 任务实现、组件改动、页面联调验证 | `frontend-design,feature-development` | `reviewer` |
| `backend-dev` | 后端开发 | API/模型/数据库/鉴权/业务流程开发 | `feature-development,systematic-debugging` | `reviewer` |
| `reviewer` | 代码审核 | 质量审查、安全审计、一致性复核、风险分级 | `systematic-debugging,requesting-code-review` | `main/backend-dev/frontend-dev/tester` |
| `tester` | 测试验收 | 用例设计与执行、回归验证、异常场景检查 | `webapp-testing,auto-fix` | `main` |
| `deployer` | 发布运维 | 发布、健康检查、部署回滚、验收结果 | `db-deploy,deployment-test` | `main` |

### 4.2 Agent 职责细节

#### `main`
- 输入：`main:task_id`、用户需求、历史上下文。
- 行为：先确认范围与验收标准，不确认不执行。
- 输出：阶段结论、分发指令、汇总报告。
- 规则：不得直接修改业务代码。

#### `coordinator`
- 输入：拆分对象（功能/页面/API）、规模、紧急度。
- 行为：并发规划前后端，分配 `frontend-dev` 与 `backend-dev`。
- 输出：明确开发清单、接口边界、验证清单、回路次数（最多 3 轮）。
- 规则：只发起任务，不写落地代码。

#### `doc-writer`
- 输入：需求初稿、变更计划。
- 行为：输出 `requirements/implementation/api.md`，并给出验收标准。
- 输出：可发布文案（需求、实施、回归）。
- 规则：文本内必须有“接口变更清单”和“风险项”。

#### `frontend-dev`
- 输入：需求片段、API 约定、设计说明。
- 行为：在 Codex tmux 会话内落地前端变更。
- 输出：修改文件列表、前端验证结果（build/lint/关键 UI 检查）。
- 规则：每次任务必须带 `commit` 建议与回归路径。

#### `backend-dev`
- 输入：接口定义、数据变更约定、错误码规范。
- 行为：在 Codex tmux 会话内完成接口开发、鉴权、验证。
- 输出：API 清单、状态码规范、迁移说明。
- 规则：禁止只改一处后未同步接口文档。

#### `reviewer`
- 输入：开发提交、Diff、关键文件。
- 行为：代码质量+安全检查，输出 Pass/Reject 与修复优先级。
- 输出：P0-P3 风险分级，必须修复项清单。
- 规则：一律给出可执行修复建议，不要只给抽象评论。

#### `tester`
- 输入：已审阅通过代码、测试目标、场景列表。
- 行为：执行自动化+人工验收清单，输出报告。
- 输出：通过率、失败用例、复现步骤、建议。
- 规则：失败时必须返回 `fix_required` 并附失败证据。

#### `deployer`
- 输入：待上线变更、Git commit、回滚策略。
- 行为：执行构建、迁移、服务健康检查和回滚演练。
- 输出：部署日志、健康状态、是否可逐步灰度。
- 规则：任何生产影响动作都要留痕，附检测命令。

## 5. Agent 调用链（示例）

### 5.1 一般开发链路

```js
sessions_send("coordinator", {
  task_id: "TASK-2026-0226-001",
  task: "实现登录表单并补齐错误提示",
  session_key: "project-a-login",
  priority: "high",
  output: {
    format: "structured",
    need_summary: true
  }
}, 0)
```

`coordinator` 内部拆分：

```js
sessions_send("frontend-dev", {
  task_id: "TASK-2026-0226-001",
  task: "实现登录页组件与错误提示",
  session_key: "project-a-login-frontend",
  spec_ref: "docs/requirements/REQ-2026-..."
}, 0)

sessions_send("backend-dev", {
  task_id: "TASK-2026-0226-001",
  task: "实现登录接口与鉴权边界",
  session_key: "project-a-login-backend"
}, 0)
```

并发完成后触发：

```js
sessions_send("reviewer", "审核登录功能（含前后端一致性、输入校验、边界）", 60)
```

审核通过后再：

```js
sessions_send("tester", "执行登录链路冒烟+异常用例，输出覆盖率与失败明细", 120)
```

### 5.2 失败回路（必须实现）

- reviewer fail → `frontend-dev/backend-dev` 收到 `fix_required`
- 修复完成后回到 `reviewer`
- tester fail → 回到开发修复，再 reviewer，再 tester
- 重试上限：每个阶段最多 3 轮，仍失败升级人工介入

## 6. OpenClaw 与 Codex 分工边界（重点）

### 6.1 执行边界

| 场景 | 执行者 |
|---|---|
| 需求澄清/指令拆解/角色路由 | OpenClaw |
| 代码生成 / 重构 / Bug 修复 | **Codex CLI（tmux）** |
| 审核、测试、发布决策 | OpenClaw reviewer/tester/deployer |

### 6.2 Codex 执行模型

- 默认统一模型：`gpt-5.3-codex`（稳定可控）
- 会话保留：每个任务使用独立 `session_key` 与日志目录
- 命令入口：`run-with-skills.sh <agent> "<task>" <session_key>`

## 7. 可用技能映射（按 Agent）

| Agent | 核心技能（1~2 个，避免指令稀释） | 说明 |
|---|---|---|
| coordinator | `task-decomposer`, `agent-manager` | 分发与边界确认 |
| doc-writer | `docx`, `writing-plans` | 文档交付 |
| frontend-dev | `frontend-design`, `feature-development` | 界面与交互实现 |
| backend-dev | `feature-development`, `systematic-debugging` | API 与逻辑实现 |
| reviewer | `systematic-debugging`, `requesting-code-review` | 代码审计与风险分级 |
| tester | `webapp-testing`, `auto-fix` | 测试与验证 |
| deployer | `db-deploy`, `deployment-test` | 发布与验证 |

## 8. Codex 执行脚本（统一入口）

文件路径：`~/.openclaw/workspace/skills/codex-bridge/run-with-skills.sh`

```bash
#!/usr/bin/env bash
set -euo pipefail

AGENT="${1:-coding}"
TASK="${2:-请按业务要求执行开发任务}"
PROJECT_DIR="${PROJECT_DIR:-/root/projects/DabaiPMwebsite}"
SESSION_KEY="${3:-$(date +%Y%m%d_%H%M%S)}"
HOSTNAME_NOW="${HOSTNAME_NOW:-$(hostname 2>/dev/null || echo unknown)}"
CODEX_MODEL="gpt-5.3-codex"
LOG_DIR="${HOME}/.openclaw/codex-runs/${SESSION_KEY}"

if [[ "$HOSTNAME_NOW" == *tokyo-claw* ]]; then
  EXEC_MODE="--dangerously-bypass-approvals-and-sandbox"
else
  EXEC_MODE="--full-auto"
fi

case "$AGENT" in
  main|coordinator)
    ROLE_PROMPT="你是需求协调与任务编排角色。先确认需求边界，再把任务拆成前后端可并行执行的小任务，给出执行顺序与验收标准。禁止直接修改代码。"
    SKILLS="task-decomposer,agent-manager"
    ;;
  doc-writer)
    ROLE_PROMPT="你是文档负责人。输出可直接发布的需求/实现/验收说明。必须包含需求范围、接口变更、风险项、回归清单。"
    SKILLS="docx,writing-plans"
    ;;
  frontend-dev)
    ROLE_PROMPT="你是前端开发工程师。使用 Vue3/JS/CSS 落地页面/交互。优先保证可维护性、用户体验和边界处理。"
    SKILLS="frontend-design,feature-development"
    ;;
  backend-dev)
    ROLE_PROMPT="你是后端开发工程师。实现 API、权限、数据库一致性、错误码与日志。优先保证鉴权、安全、可回滚。"
    SKILLS="feature-development,systematic-debugging"
    ;;
  reviewer)
    ROLE_PROMPT="你是代码审查角色。重点产出：风险分级(P0-P3)、问题清单、修复优先级、是否可放行。若不通过请给出可执行修复点。"
    SKILLS="systematic-debugging,requesting-code-review"
    ;;
  tester)
    ROLE_PROMPT="你是测试验收角色。输出冒烟、回归、边界和异常场景测试清单，给出通过率和失败重现实例。"
    SKILLS="webapp-testing,auto-fix"
    ;;
  deployer)
    ROLE_PROMPT="你是发布运维角色。输出部署步骤、健康检查、回滚方案和结果结论。失败时给出失败点与补救动作。"
    SKILLS="db-deploy,deployment-test"
    ;;
  *)
    ROLE_PROMPT="你是高效执行者。先给变更计划，再给最小可验证实现，最后给验证结果。"
    SKILLS="feature-development"
    ;;
esac

mkdir -p "$LOG_DIR"
TMUX_SESSION="codex-${AGENT}-${SESSION_KEY}"
TMUX_LOG="${LOG_DIR}/${AGENT}-${SESSION_KEY}.log"

PROMPT=$(cat <<EOF
你本次任务是：${TASK}

请加载并严格遵守以下技能约束：${SKILLS}

角色：
${ROLE_PROMPT}

输出要求（必须给出）：
1. 受影响文件列表（新建/修改）
2. 修改原因与验证思路
3. 接口变更说明（如有）
4. 风险与回退点
5. 建议执行的验证命令
6. 结论：through / reject / need_confirm

限制：
- 只做本任务范围内改动
- 不擅自引入无关架构
- 如有不确定点请列出问题并暂停
EOF
)

tmux new-session -d -s "$TMUX_SESSION" \
  "cd '$PROJECT_DIR' && codex $EXEC_MODE --model $CODEX_MODEL exec \"$PROMPT\" | tee '$TMUX_LOG'"

echo "agent=$AGENT"
echo "session=$TMUX_SESSION"
echo "log=$TMUX_LOG"
echo "mode=$EXEC_MODE"
echo "skills=$SKILLS"
```

### 8.1 标准调用方式（必须）

```bash
cd ~/.openclaw/workspace/skills/codex-bridge

# 协调
bash run-with-skills.sh coordinator "梳理登录功能拆分并确认边界" "login-001"

# 前后端并行
bash run-with-skills.sh frontend-dev "实现登录页组件与表单错误提示" "login-001-fe"
bash run-with-skills.sh backend-dev "实现登录API鉴权与参数校验" "login-001-be"

# 审核与测试
bash run-with-skills.sh reviewer "审查登录功能实现，给出是否放行结论" "login-001-review"
bash run-with-skills.sh tester "执行登录功能回归测试并给报告" "login-001-test"
```

## 9. tmux 执行规范（关键）

- 全局规则：代码任务只能通过 `tmux + run-with-skills.sh` 触发；不允许在 OpenClaw 直接 `exec` 长任务。
- 日志目录：`~/.openclaw/codex-runs/<task_id>/`
- 会话命名：`codex-<agent>-<task_id>`
- 任务关闭：会话结束后保留日志，不自动清理

```bash
tmux ls
tmux capture-pane -pt <session_name> -n 300
tmux attach -t <session_name>
tmux kill-session -t <session_name>   # 确认完成后再手动清理
```

### 9.1 大任务并行模板（前后端并行 + 日志汇总）

```bash
TASK_ID=login-20260226-001
PROJECT_DIR=/root/projects/DabaiPMwebsite
LOG_DIR=~/.openclaw/codex-runs/$TASK_ID
mkdir -p "$LOG_DIR"

cd ~/.openclaw/workspace/skills/codex-bridge
bash run-with-skills.sh frontend-dev "开发登录页与前端联调" "${TASK_ID}-fe"
bash run-with-skills.sh backend-dev "开发登录 API 与鉴权链路" "${TASK_ID}-be"

tmux ls | grep "${TASK_ID}"
```

## 10. 质量与复盘要求

### 10.1 必须输出（每次 Codex 任务后）
- task_id
- 修改文件
- 自检命令（至少一条）
- 风险与回退点
- 当前建议状态：`done / need_fix / blocked`

### 10.2 全链路状态命令

```bash
openclaw agents list --bindings
openclaw config get tools.agentToAgent
openclaw agents status
openclaw channels status --probe
openclaw config get channels_telegram
```

## 11. 常用验证模板（可直接粘贴到群里回报）

- [完成] `frontend-dev login-001-fe`: 修改 4 文件，完成 form+错误提示，`pnpm -C frontend build` 通过
- [待审] `backend-dev login-001-be`: 修改 3 文件，登录接口参数校验补齐
- [修复] reviewer: P1 问题 2 个，要求限制失败重试次数
- [验收] tester: 关键用例 6/6 通过，边界用例 2/2 通过
- [最终] main: 需求范围 100%，等待上线或部署指令

## 12. 版本记录

| 日期 | 版本 | 变更 |
|---|---|---|
| 2026-02-26 | v1.15.0 | 回退“过度精简”策略，恢复完整 8 Agent 角色定义、技能映射、tmux+codex 双层调用链 |
| 2026-02-26 | v1.14.1 | tmux 与 Codex 行为补充 |
| 2026-02-25 | v1.13.0 | 多 Agent 通道与超时/权限补齐 |

